## Module <auto_database_backup>

#### 31.10.2022
#### Version 16.0.1.0.0
#### ADD

- Initial commit for auto_database_backup

## Module <auto_database_backup>

#### 26.09.2023
#### Version 16.0.2.0.1
#### ADD

- Next Cloud Integration and Amazon S3 are added and added active field customization if connection is successful only then active field will be able to edit.

## Module <auto_database_backup>

#### 07.12.2023
#### Version 16.0.3.0.2
#### UPDT

- Updated the database name check function which got access denied when list_db=False.